#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
patterns=[(r'\brequests\.', 'network'),(r'\burllib\.request','url'),(r'\bsocket\.','socket'),(r'\beval\(','eval'),(r'\bexec\(','exec'),(r'openai','model api'),(r'camera|getUserMedia|microphone','sensor'),(r'localStorage','browser storage')]
findings=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.name=='static_boundary_audit.py' or p.suffix.lower() not in {'.py','.html','.js','.json','.md'}: continue
    text=p.read_text(encoding='utf-8',errors='ignore')
    for pat,meaning in patterns:
        if re.search(pat,text,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning,'pattern':pat})
result={'package':'DIKWP MentalHealth TriageCare RehabOS 2026 V1','unsafe_capability_detected':bool(findings),'findings':findings,'note':'No diagnosis model, sensor capture, network call, or emergency replacement adapter is intended.'}
(ROOT/'static_boundary_audit_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
