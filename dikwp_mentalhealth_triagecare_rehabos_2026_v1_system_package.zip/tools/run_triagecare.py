#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from datetime import datetime, timezone

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('case', type=Path)
    ap.add_argument('--out', type=Path, default=Path('outputs'))
    args=ap.parse_args()
    case=json.loads(args.case.read_text(encoding='utf-8'))
    level=case.get('action','C2')
    if level.startswith('C5') or '自杀' in ''.join(case.get('safety',[])):
        level='C5'
    passport={
      'version':'DIKWP MentalHealth TriageCare RehabOS 2026 V1 CLI',
      'generated_at':datetime.now(timezone.utc).isoformat(),
      'case_id':case.get('id'),
      'synthetic':True,
      'action_level':level,
      'boundaries':{'diagnosis':False,'prescription':False,'emergency_replacement':False,'clinician_review_required':True},
      'next_steps':['check red flags','contact emergency/professional resources if C4/C5','prepare evidence ledger','human review']
    }
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/f"{case.get('id','case')}_care_passport.json"
    target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Created',target)
    print('Boundary: not diagnosis, not prescription, not emergency replacement.')
if __name__=='__main__': main()
