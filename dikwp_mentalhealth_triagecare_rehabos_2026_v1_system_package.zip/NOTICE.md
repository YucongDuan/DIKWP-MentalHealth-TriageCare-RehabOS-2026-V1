# NOTICE

DIKWP MentalHealth TriageCare RehabOS 2026 V1 is a synthetic-data reference implementation for research, education, safety workflow design, and low-risk care-coordination prototyping.

Attribution: Yucong Duan / DIKWP ecosystem reference implementation.

The package does not provide diagnosis, medical advice, psychiatric treatment, psychotherapy, medication advice, crisis intervention, hospitalization decisions, legal advice, or emergency response.
