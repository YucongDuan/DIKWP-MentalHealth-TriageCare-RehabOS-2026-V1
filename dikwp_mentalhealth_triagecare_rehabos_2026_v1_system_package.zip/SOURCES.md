# Sources

- WHO mhGAP guideline for mental, neurological and substance use disorders, 2023.
- WHO mhGAP Intervention Guide, Version 2.0, 2019.
- WHO Comprehensive Mental Health Action Plan 2013–2030, updated 2021.
- WHO LIVE LIFE suicide prevention implementation guide, 2021.
- WHO Ethics and governance of artificial intelligence for health, 2021; WHO guidance on large multi-modal models, 2025.
- National Health Commission of China, Mental Health Law of the People's Republic of China.
- National Health Commission of China, 12356 national psychological assistance hotline notice, 2024.
- Healthy China Action 2019–2030, Mental Health Promotion Action.
- NICE NG225 Self-harm: assessment, management and preventing recurrence, 2022.
- NICE NG222 Depression in adults: treatment and management, 2022, last reviewed 2026.
- SAMHSA working definition of recovery, 2012; recovery resources, 2023.
- American Psychiatric Association App Evaluation Model.

All clinical use must follow local law, licensed professional judgment, and current clinical guidelines.
