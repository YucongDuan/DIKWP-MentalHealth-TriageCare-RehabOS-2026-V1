# Governance and Safety Boundary

## Non-negotiable prohibitions

The system must not:
- diagnose mental disorders
- prescribe, stop, change, or recommend medication doses
- decide hospitalization, discharge, restraint, guardianship, or involuntary treatment
- replace emergency services, crisis hotlines, psychiatrists, psychotherapists, or legal procedures
- predict future suicide, violence, relapse, or dangerousness as a score
- use face, voice, emotion recognition, social-media scraping, or secret surveillance
- advise self-harm methods or provide dangerous details
- store identifying information beyond the minimum necessary

## Required controls

- action-level triage rather than diagnostic labels
- red-flag gate before any supportive content
- evidence ledger with source, support scope, and limits
- residuals and kill conditions
- human clinician review for any clinical decision
- crisis escalation to emergency services where needed
- privacy minimization and user-visible records
- AI-use logging and audit export

## Kill conditions

Stop or downgrade if:
- imminent self-harm or violence is indicated
- safety information is missing and the person may be alone or unable to stay safe
- psychosis, mania, delirium, intoxication, withdrawal, seizure, chest pain, postpartum acute change, or other medical red flags appear
- a minor or vulnerable adult lacks safe supervision
- AI attempts diagnosis, medication, hospitalization, or therapy replacement
- the output may delay real-world care
