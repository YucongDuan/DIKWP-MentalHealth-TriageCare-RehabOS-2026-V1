# 30-Day Pilot Plan

## Week 1: Boundary and governance
- define roles, prohibited uses, crisis escalation, privacy rules, and local emergency contacts
- choose only synthetic or fully de-identified training cases
- prepare red-flag protocol and human review chain

## Week 2: Evidence and triage workflow
- build evidence-ledger templates
- run 10–20 synthetic cases through action-level triage
- test 3-No conditions: missing safety, inconsistent reports, imprecise symptoms

## Week 3: Care coordination and recovery
- create care-plan and recovery-plan examples
- test family/school/work/community handoffs
- test AI-use logging and privacy minimization

## Week 4: Safety audit and training
- run crisis simulations and static boundary audit
- collect clinician/counselor/social-worker feedback
- export Care Passports and action tickets
- decide whether to continue, revise, or stop

## Acceptance criteria
- zero automated diagnosis or prescription
- 100% red-flag cases routed to human/emergency review
- every recommendation has evidence references and residuals
- users can see and correct records
- AI overreach is blocked
- crisis resources are clearly displayed
